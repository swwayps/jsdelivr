#!/bin/bash

SLSDIR="$HOME/.local/share/SLSsteam"
SLSLIB="$SLSDIR/SLSsteam.so"
OS_RELEASE_FILE="${OS_RELEASE_FILE:-/etc/os-release}"

# User-local applications dir (XDG override always wins over system-wide).
USER_APPS="${XDG_DATA_HOME:-$HOME/.local/share}/applications"
USER_DESKTOP="$USER_APPS/steam.desktop"
SYS_DESKTOP="/usr/share/applications/steam.desktop"

# XDG autostart: some images (SteamOS/Bazzite) auto-launch Steam on desktop
# login via /etc/xdg/autostart/steam.desktop (which calls the distro launcher,
# bypassing our wrapper). A user-level entry of the same basename overrides it.
USER_AUTOSTART="${XDG_CONFIG_HOME:-$HOME/.config}/autostart/steam.desktop"
SYS_AUTOSTART="/etc/xdg/autostart/steam.desktop"

# Tag we drop into patched .desktop files so we can detect/undo them later.
SLSM_TAG="X-SLSteamMoon-Patched=true"

# Desktop-coverage logic (scan + patch every *steam*.desktop, blindagens,
# restore) lives in one sourceable lib shared with the wrapper and Lumen. Source
# the in-repo copy at install time so dc_run / dc_restore_all are available here.
WRAPPER="$SLSDIR/path/steam"
DC_TAG="$SLSM_TAG"
DC_BACKUP_ROOT="$SLSDIR/backup"
SETUP_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
if [ -f "$SETUP_DIR/tools/desktop-coverage.lib.sh" ]; then
	# shellcheck source=/dev/null
	. "$SETUP_DIR/tools/desktop-coverage.lib.sh"
fi
if [ -f "$SETUP_DIR/tools/launcher-shim.lib.sh" ]; then
	# shellcheck source=/dev/null
	. "$SETUP_DIR/tools/launcher-shim.lib.sh"
fi
if [ -f "$SETUP_DIR/tools/desktop-guardian-units.lib.sh" ]; then
	# shellcheck source=/dev/null
	. "$SETUP_DIR/tools/desktop-guardian-units.lib.sh"
fi

# ============================================================================
# Pretty output (colors + box-drawing). Falls back to plain text when stdout
# is not a TTY or the terminal does not advertise colour support.
#
# Palette: "moonlit night" — cool blues for structure, silver-white for the
# moon glyph, standard semantic colours for status. Uses 256-colour escapes
# when the terminal supports them, otherwise degrades to 8-colour ANSI.
# ============================================================================

if [ -t 1 ] && [ -z "${NO_COLOR:-}" ] && [ "${TERM:-dumb}" != "dumb" ]; then
	# Detect 256-colour support. tput is the reliable check; default to true
	# if tput is unavailable but COLORTERM looks modern.
	if command -v tput >/dev/null 2>&1 && [ "$(tput colors 2>/dev/null || echo 0)" -ge 256 ]; then
		HAS_256=1
	elif [ "${COLORTERM:-}" = "truecolor" ] || [ "${COLORTERM:-}" = "24bit" ]; then
		HAS_256=1
	else
		HAS_256=0
	fi

	BOLD=$'\033[1m'
	DIM=$'\033[2m'
	NC=$'\033[0m'

	if [ "$HAS_256" = 1 ]; then
		MOON=$'\033[38;5;153m'
		NIGHT=$'\033[38;5;75m'
		HALO=$'\033[38;5;231m'
		MUTED=$'\033[38;5;110m'
		GREEN=$'\033[38;5;114m'
		YELLOW=$'\033[38;5;221m'
		RED=$'\033[38;5;203m'
	else
		MOON=$'\033[1;34m'
		NIGHT=$'\033[0;36m'
		HALO=$'\033[1;37m'
		MUTED=$'\033[0;34m'
		GREEN=$'\033[0;32m'
		YELLOW=$'\033[0;33m'
		RED=$'\033[0;31m'
	fi
else
	BOLD=""; DIM=""; NC=""
	MOON=""; NIGHT=""; HALO=""; MUTED=""
	GREEN=""; YELLOW=""; RED=""
fi

print_banner() {
	echo ""
	echo -e "${MOON}${BOLD}"
	echo "┌─────────────────────────────────────────────────────────┐"
	printf "│             ${HALO}${BOLD}◯${NC}${MOON}${BOLD}  slsteam-moon installer                   │\n"
	echo "└─────────────────────────────────────────────────────────┘"
	echo -e "${NC}"
}

print_section() {
	echo ""
	echo -e "${NIGHT}─────────────────────────────────────────────────────────${NC}"
	echo -e "${NIGHT}${BOLD}❯ $1${NC}"
	echo -e "${NIGHT}─────────────────────────────────────────────────────────${NC}"
}

log_info()    { echo -e "${NIGHT}→${NC} $1"; }
log_success() { echo -e "${GREEN}✓${NC} $1"; }
log_warn()    { echo -e "${YELLOW}⚠${NC} $1"; }
log_error()   { echo -e "${RED}✗${NC} $1"; }
log_step()    { echo -e "${MOON}•${NC} $1"; }

print_install_complete() {
	echo ""
	echo -e "${GREEN}${BOLD}"
	echo "┌─────────────────────────────────────────────────────────┐"
	echo "│        ✓ slsteam-moon Installation Completed!           │"
	echo "└─────────────────────────────────────────────────────────┘"
	echo -e "${NC}"
}

print_uninstall_complete() {
	echo ""
	echo -e "${GREEN}${BOLD}"
	echo "┌─────────────────────────────────────────────────────────┐"
	echo "│               ✓ Uninstall Complete!                     │"
	echo "└─────────────────────────────────────────────────────────┘"
	echo -e "${NC}"
	echo ""
	echo -e "   Restart your terminal and Steam for changes to take effect."
	echo ""
}

# ============================================================================
# Detection helpers
# ============================================================================

# True on immutable / atomic systems (Bazzite, SteamOS, Fedora Atomic/ublue, …)
# where /usr is read-only: we must NOT attempt the system-wide .desktop patch
# (it would prompt for sudo then fail silently). User-level entries override the
# system ones via XDG precedence, so --user fully covers the normal launchers.
is_immutable_distro() {
	case "${SLSM_IMMUTABLE:-}" in
		1|yes|true) return 0 ;;
		0|no|false) return 1 ;;
	esac

	local id="" like="" variant=""
	if [ -r "$OS_RELEASE_FILE" ]; then
		id="$(
			# shellcheck disable=SC1090
			. "$OS_RELEASE_FILE" >/dev/null 2>&1
			printf '%s' "${ID:-}"
		)"
		like="$(
			# shellcheck disable=SC1090
			. "$OS_RELEASE_FILE" >/dev/null 2>&1
			printf '%s' "${ID_LIKE:-}"
		)"
		variant="$(
			# shellcheck disable=SC1090
			. "$OS_RELEASE_FILE" >/dev/null 2>&1
			printf '%s' "${VARIANT_ID:-}"
		)"
	fi
	id="${id,,}"; like="${like,,}"; variant="${variant,,}"
	case " $id $like " in
		*" bazzite "*|*" steamos "*|*" steamdeck "*|*" holoiso "*|\
		*" silverblue "*|*" kinoite "*|*" sericea "*|*" onyx "*|\
		*" bluefin "*|*" aurora "*|*" ucore "*) return 0 ;;
	esac
	case "$variant" in silverblue|kinoite|sericea|onyx|*atomic*) return 0 ;; esac
	command -v rpm-ostree >/dev/null 2>&1 && return 0
	command -v steamos-readonly >/dev/null 2>&1 && return 0
	if command -v findmnt >/dev/null 2>&1; then
		case ",$(findmnt -no OPTIONS / 2>/dev/null)," in *,ro,*) return 0 ;; esac
	fi
	return 1
}

# Find the real Steam binary. Distros vary:
#   /usr/games/steam        Debian, Ubuntu, Mint (steam-installer)
#   /usr/bin/steam          Arch, Fedora, openSUSE, Manjaro, Pop!_OS
#   /usr/local/bin/steam    manual installs
detect_steam_binary() {
	local c
	for c in /usr/games/steam /usr/bin/steam /usr/local/bin/steam; do
		if [ -x "$c" ]; then
			echo "$c"
			return 0
		fi
	done
	command -v steam 2>/dev/null
}

# Tell the Mint/Debian "steam-installer" stub apart from a real Steam launcher.
# The stub has Name=Install Steam.
is_real_steam_desktop() {
	local f="$1"
	[ -f "$f" ] || return 1
	# Already patched by us — treat as real (don't recurse).
	grep -q "$SLSM_TAG" "$f" 2>/dev/null && return 0
	# Stub installer, skip it.
	grep -q "^Name=Install Steam" "$f" 2>/dev/null && return 1
	# Heuristic: any Exec= line that runs steam directly.
	grep -qE "^Exec=.*((^| |\")steam( |\$|%)|/steam( |\$|%)|/games/steam|/bin/steam)" "$f" 2>/dev/null
}

# Already patched to use our wrapper?
is_patched_desktop() {
	[ -f "$1" ] && grep -q "$SLSM_TAG" "$1" 2>/dev/null
}

# Locate a "donor" .desktop to seed the user-local override from when the user
# doesn't already have one. Tries, in order: existing user-local (real), the
# system-wide entry (real), and the bundle Steam itself ships under
# ~/.steam/.../steam-launcher/.
find_donor_desktop() {
	local c
	if is_real_steam_desktop "$USER_DESKTOP"; then
		echo "$USER_DESKTOP"; return 0
	fi
	if is_real_steam_desktop "$SYS_DESKTOP"; then
		echo "$SYS_DESKTOP"; return 0
	fi
	for c in \
		"$HOME/.steam/steam/steam-launcher/steam.desktop" \
		"$HOME/.steam/debian-installation/deb-installer/steam-launcher/steam.desktop" \
		"$HOME/.steam/debian-installation/deb-installer/steam.desktop"; do
		if is_real_steam_desktop "$c"; then
			echo "$c"; return 0
		fi
	done
	return 1
}

# ============================================================================
# Steam process management
# ============================================================================

# Stop any running Steam so the wrapper / desktop entry takes effect on next
# launch. Tries graceful shutdown first, falls back to SIGTERM then SIGKILL.
kill_steam() {
	# Steam's own processes, by name: the client, its launcher scripts and the
	# web helper. A command-line match would also hit an editor or a shell
	# that merely names a path ending in /steam.
	local uid names
	uid="$(id -u)"
	names='steam|steam\.sh|steamwebhelper'
	if ! pgrep -u "$uid" -x "$names" >/dev/null 2>&1; then
		log_success "No running Steam process detected"
		return 0
	fi
	log_info "Stopping running Steam processes"
	if command -v steam >/dev/null 2>&1; then
		# Sandboxed launchers replicate the caller's cwd inside their sandbox.
		# The installer may still be inside a temporary extraction directory,
		# which does not exist in that sandbox. Keep the shutdown request local
		# to this subshell so setup.sh itself retains its current directory.
		(
			cd "$HOME" 2>/dev/null || cd / 2>/dev/null || exit 0
			steam -shutdown >/dev/null 2>&1
		) || true
	fi

	for _ in 1 2 3 4 5; do
		if ! pgrep -u "$uid" -x "$names" >/dev/null 2>&1; then
			log_success "Steam stopped"
			return 0
		fi
		sleep 1
	done
	pkill -TERM -u "$uid" -x "$names" 2>/dev/null || true
	sleep 2
	if pgrep -u "$uid" -x "$names" >/dev/null 2>&1; then
		log_warn "Steam still running — sending SIGKILL"
		pkill -KILL -u "$uid" -x "$names" 2>/dev/null || true
		sleep 1
	fi
	if pgrep -u "$uid" -x "$names" >/dev/null 2>&1; then
		log_warn "Steam is still running"
	else
		log_success "Steam stopped"
	fi
}

# ============================================================================
# Install steps
# ============================================================================

install_slssteam()
{
	LIB="./bin/SLSsteam.so"

	if [ ! -f "$LIB" ]; then
		log_error "$LIB not found"
		echo ""
		echo "   If you're a developer, build it first:"
		echo -e "     ${GREEN}scripts/build.sh --portable${NC}  ${MUTED}# For releases (requires Podman/Docker)${NC}"
		echo -e "     ${GREEN}make${NC}               ${MUTED}# For local testing${NC}"
		echo ""
		exit 1
	fi

	log_info "Installing SLSsteam libraries"
	mkdir -p "$SLSDIR" || exit 1
	cp -v ./bin/* "$SLSDIR/" | sed "s|^|   ${MUTED}${NC}|"
	# Older releases shipped a second audit module; an old desktop entry that
	# still names it would load it next to SLSsteam.
	rm -f "$SLSDIR/library-inject.so"
	# Desktop-coverage helper (scan + patch all *steam*.desktop). Shipped in the
	# release; copied next to the wrapper so the wrapper and Lumen can invoke it.
	install -m 0644 ./tools/desktop-coverage.lib.sh "$SLSDIR/desktop-coverage.lib.sh" 2>/dev/null || \
		cp ./tools/desktop-coverage.lib.sh "$SLSDIR/desktop-coverage.lib.sh"
	install -m 0644 ./tools/launcher-shim.lib.sh "$SLSDIR/launcher-shim.lib.sh" 2>/dev/null || \
		cp ./tools/launcher-shim.lib.sh "$SLSDIR/launcher-shim.lib.sh"
	install -m 0644 ./tools/desktop-guardian-units.lib.sh "$SLSDIR/desktop-guardian-units.lib.sh" 2>/dev/null || \
		cp ./tools/desktop-guardian-units.lib.sh "$SLSDIR/desktop-guardian-units.lib.sh"
	install -m 0755 ./ensure-desktop-coverage.sh    "$SLSDIR/ensure-desktop-coverage.sh" 2>/dev/null || \
		{ cp ./ensure-desktop-coverage.sh "$SLSDIR/ensure-desktop-coverage.sh"; chmod +x "$SLSDIR/ensure-desktop-coverage.sh"; }
	log_success "Libraries installed at $SLSDIR"
	echo ""
}

create_steam_wrapper()
{
	log_info "Creating Steam wrapper with SLSsteam injection"

	mkdir -p "$SLSDIR/path"

	# The wrapper resolves the real Steam binary at runtime so the install is
	# portable across distros (and survives moves between, e.g., a Debian-style
	# /usr/games/steam and an Arch-style /usr/bin/steam).
	cat > "$SLSDIR/path/steam" << 'EOF'
#!/bin/sh
# slsteam-moon wrapper. Injects SLSsteam via LD_AUDIT (rtld-audit) so the audit
# namespace can't interpose on Steam's own copies of protobuf / yaml-cpp /
# libstdc++. SLSsteam must be our only auditor: with a second one loaded, any
# exception thrown inside it aborts Steam. CloudRedirect (cloud saves) is
# injected separately via LD_PRELOAD (see its block below).
SLSDIR="$HOME/.local/share/SLSsteam"

# Desktop entries from older installs may invoke this wrapper with our audit
# DSOs already present in LD_AUDIT.  Remove only our known objects immediately,
# before helper commands (readlink, stat, awk, …) are spawned.  An inherited
# third-party auditor is preserved and is reattached after the guard has made
# its decision.
slsm_strip_own_auditors() {
	_slsm_old_ifs="$IFS"
	IFS=:
	_slsm_clean=""
	for _slsm_audit in ${LD_AUDIT:-}; do
		case "$_slsm_audit" in
			''|*SLSsteam.so|*library-inject.so|*libSLSsteam.so|*libSLS-library-inject.so)
				continue ;;
			*)
				_slsm_clean="${_slsm_clean:+$_slsm_clean:}$_slsm_audit" ;;
		esac
	done
	IFS="$_slsm_old_ifs"
	printf '%s' "$_slsm_clean"
}
SLSM_INHERITED_AUDIT="$(slsm_strip_own_auditors)"
if [ -n "$SLSM_INHERITED_AUDIT" ]; then
	export LD_AUDIT="$SLSM_INHERITED_AUDIT"
else
	unset LD_AUDIT
fi

# Resolve the real Steam binary, skipping our own wrapper.
SELF="$(readlink -f "$0" 2>/dev/null || echo "$0")"
STEAM_BIN=""
SLSM_EXPLICIT_STEAM_BIN=0
# A retained mirrored backup can itself be a managed shim after an interrupted
# restore. Never let an explicit hook promote that shim back into the launch
# chain; resolve a vanilla Steam path instead.
if [ -n "${SLSM_STEAM_BIN:-}" ] && \
   head -3 "$SLSM_STEAM_BIN" 2>/dev/null | \
   grep -qF "slsteam-moon system launcher shim"; then
	unset SLSM_STEAM_BIN
fi
# Override hook: an explicit, executable path wins. Lets power users pin a
# specific Steam binary and lets the wrapper guard's unit test inject a fake
# Steam; a no-op when unset.
if [ -n "${SLSM_STEAM_BIN:-}" ] && [ -x "${SLSM_STEAM_BIN:-}" ] && \
   [ "$(readlink -f "$SLSM_STEAM_BIN" 2>/dev/null || echo "$SLSM_STEAM_BIN")" != "$SELF" ]; then
	STEAM_BIN="$SLSM_STEAM_BIN"
	SLSM_EXPLICIT_STEAM_BIN=1
fi
if [ -z "$STEAM_BIN" ]; then
	for c in /usr/games/steam /usr/bin/steam /usr/local/bin/steam; do
		if [ -x "$c" ] \
			&& [ "$(readlink -f "$c" 2>/dev/null || echo "$c")" != "$SELF" ] \
			&& ! head -3 "$c" 2>/dev/null | grep -q "slsteam-moon system launcher shim"; then
			STEAM_BIN="$c"
			break
		fi
	done
fi
if [ -z "$STEAM_BIN" ]; then
	# Fall back to PATH lookup, but skip ourselves.
	IFS=:
	for d in $PATH; do
		c="$d/steam"
		if [ -x "$c" ] \
			&& [ "$(readlink -f "$c" 2>/dev/null || echo "$c")" != "$SELF" ] \
			&& ! head -3 "$c" 2>/dev/null | grep -q "slsteam-moon system launcher shim"; then
			STEAM_BIN="$c"
			break
		fi
	done
	unset IFS
fi
# All system launchers are our shims or absent.  Fall back to the
# steam.sh script inside the Steam data directory (it is what the
# system launcher would exec anyway once the bootstrap is set up).
if [ -z "$STEAM_BIN" ]; then
	for c in "${HOME}/.local/share/Steam/steam.sh" \
	         "${HOME}/.steam/steam/steam.sh" \
	         "${HOME}/.steam/debian-installation/steam.sh"; do
		if [ -x "$c" ]; then
			STEAM_BIN="$c"
			break
		fi
	done
fi
if [ -z "$STEAM_BIN" ]; then
	echo "slsteam-moon: could not find the real Steam binary" >&2
	exit 127
fi
# Canonicalize relative paths before we touch cwd below. Absolute paths must
# remain verbatim because the bootstrap guard below matches their managed
# launcher prefixes literally.
case "$STEAM_BIN" in
	/*) ;;
	*) STEAM_BIN="$(readlink -f "$STEAM_BIN" 2>/dev/null || echo "$STEAM_BIN")" ;;
esac

# Valve's distro launcher (bin_steam.sh, which /usr/bin/steam symlinks to on
# Fedora/Nobara) takes its whole identity from its own argv[0]:
#
#     STEAMPACKAGE="${0##*/}" ... *) log "Unknown Steam package"; exit 1
#
# A captured original such as system-launcher-backup/usr/bin/steam.orig is
# exactly that case, so exec'ing it aborts the launch before Steam opens its
# logger: Steam silently never starts and no log is written anywhere. Never
# exec a launcher under a name it can reject - route through a `steam`-named
# alias for the same file. This also heals a shim written by an older release
# that still hands over the `.orig` path directly.
# SLSM_POLICY_BIN keeps the resolved path so the bootstrap guard below still
# classifies the launcher by what was actually resolved, not by the alias.
SLSM_POLICY_BIN="$STEAM_BIN"
slsm_launcher_name_safe() {
	case "${1##*/}" in
		steam|steambeta|bin_steam.sh|steam.sh) return 0 ;;
	esac
	return 1
}
slsm_same_file() {
	_slsm_a="$(readlink -f "$1" 2>/dev/null || true)"
	_slsm_b="$(readlink -f "$2" 2>/dev/null || true)"
	[ -n "$_slsm_a" ] && [ "$_slsm_a" = "$_slsm_b" ]
}
slsm_normalize_launcher() {
	slsm_launcher_name_safe "$STEAM_BIN" && return 0
	# 1) The alias the installer keeps next to the captured original.
	_slsm_sibling="${STEAM_BIN%/*}/steam"
	if [ -x "$_slsm_sibling" ] && slsm_same_file "$_slsm_sibling" "$STEAM_BIN"; then
		STEAM_BIN="$_slsm_sibling"
		return 0
	fi
	# 2) A private alias we own, created on demand.
	_slsm_alias_dir="$SLSDIR/launcher-alias"
	_slsm_alias="$_slsm_alias_dir/steam"
	if mkdir -p "$_slsm_alias_dir" 2>/dev/null; then
		if ! slsm_same_file "$_slsm_alias" "$STEAM_BIN"; then
			[ -L "$_slsm_alias" ] || rm -f "$_slsm_alias" 2>/dev/null || true
			ln -sfn "$STEAM_BIN" "$_slsm_alias" 2>/dev/null || true
		fi
		if [ -x "$_slsm_alias" ] && slsm_same_file "$_slsm_alias" "$STEAM_BIN"; then
			STEAM_BIN="$_slsm_alias"
			return 0
		fi
	fi
	# 3) Nothing aliasable: the data-dir steam.sh ignores its own name.
	for _slsm_c in "${HOME}/.local/share/Steam/steam.sh" \
	               "${HOME}/.steam/steam/steam.sh" \
	               "${HOME}/.steam/debian-installation/steam.sh"; do
		if [ -x "$_slsm_c" ]; then
			STEAM_BIN="$_slsm_c"
			return 0
		fi
	done
	return 1
}
slsm_normalize_launcher || true

# Some Steam launchers (Nix's FHS/bwrap wrapper) replicate our cwd inside
# their sandbox via --chdir. If we were started from a short-lived temp dir
# (an installer extracting to $(mktemp -d) before running us), the sandbox's
# isolated /tmp won't have it and bwrap fails to chdir. $HOME is always
# there, so pin cwd to it now that STEAM_BIN is resolved.
cd "$HOME" 2>/dev/null || cd / 2>/dev/null || true

slsm_exec_vanilla() {
	# Safe mode must not depend on what a desktop entry or parent shell put in
	# the loader environment.  Unset the complete loader surface, not only our
	# own names, so a broken third-party preload cannot keep the recovery loop.
	exec env -u LD_AUDIT -u LD_PRELOAD -u LD_LIBRARY_PATH "$STEAM_BIN" "$@"
}

# Debian's Install Steam package stub is a valid executable before the client
# root exists, but it is not a Steam client and must never receive injection.
# Explicit test/pinned binaries remain eligible; captured originals from our
# launcher backups (root's tree or the user's) are shim-originated and still
# require bootstrap.
slsm_bootstrap_guard() {
	if [ "${SLSM_EXPLICIT_STEAM_BIN:-0}" = 1 ]; then
		case "$SLSM_POLICY_BIN" in
			"$SLSDIR/system-launcher-backup/"*|/var/lib/slsteam-moon/launcher-backup/*) ;;
			*) return 0 ;;
		esac
	else
		case "$SLSM_POLICY_BIN" in
			/usr/games/steam|/usr/bin/steam|/usr/local/bin/steam) ;;
			*) return 0 ;;
		esac
	fi
	[ -L "$HOME/.steam/steam" ] || return 1
	_slsm_bootstrap_root="$(readlink -e "$HOME/.steam/steam" 2>/dev/null || true)"
	[ -n "$_slsm_bootstrap_root" ] || return 1
	[ -f "$_slsm_bootstrap_root/steam.sh" ] && \
		[ -x "$_slsm_bootstrap_root/steam.sh" ]
}
if ! slsm_bootstrap_guard; then
	slsm_exec_vanilla "$@"
fi

# ---------------------------------------------------------------------------
# Crash-loop fail-safe (Game Mode boot protection).
#
# In a gamescope "Game Mode" session the supervisor relaunches Steam every time
# it exits. If our injected stack (SLSsteam via LD_AUDIT / CloudRedirect via
# LD_PRELOAD / the Lumen sidecar) goes incompatible with a freshly-updated Steam
# client and stalls the engine, the device loops on the splash forever and the
# user can never reach Desktop Mode to update. This guard counts boots that
# CRASHED AT STARTUP (Steam wrote an assert/crash minidump within the boot's
# first few minutes) and, past a threshold, LATCHES into a safe mode that starts
# Steam completely vanilla (no LD_AUDIT, no LD_PRELOAD, no sidecar) so the
# session comes up. The latch is scoped to THAT SESSION: a relaunch loop lives
# entirely inside one boot, so a boot is all the time pausing injection needs to
# cover, and every new session re-arms it. (A latch that outlived the boot left
# the user on a silently unhooked Steam - no plugin UI, no explanation - that
# only a payload reinstall could undo.) We deliberately key off the crash dump
# and NOT merely a short-lived session: switching Game Mode <-> Desktop, a client
# self-update restart, or a quick manual quit all end Steam fast but are NOT
# failures, and a clean kill never writes a dump. As a fast path, a startup crash whose
# steamclient.so differs from the last cleanly-booted one latches on the FIRST
# crash (a fresh client is the near-certain cause), so the user is not made to
# loop MAX_FAILS times for a known-cause break; a crash on an UNCHANGED client
# keeps the conservative MAX_FAILS threshold. Session/distro-agnostic: ChimeraOS/Bazzite
# (sessions.d STEAMCMD), SteamOS (steam-launcher PATH drop-in) and Desktop Mode
# all funnel through this one wrapper. Every step is best-effort and can never
# itself block the launch.
GUARD_DIR="${XDG_STATE_HOME:-$HOME/.local/state}/slsteam-moon"
mkdir -p "$GUARD_DIR" 2>/dev/null || true
GUARD_LAST="$GUARD_DIR/last_launch"          # mtime = start of the most recent boot
GUARD_GFX="$GUARD_DIR/last_launch_display"   # 1/0: did the most recent launch have a display
GUARD_COUNT="$GUARD_DIR/boot_fail_count"
GUARD_SAFE="$GUARD_DIR/safe_mode"            # present => stay vanilla
GUARD_FP="$GUARD_DIR/safe_mode_fingerprint"  # payload id captured when latched
GUARD_SESSION="$GUARD_DIR/session_id"        # session the latch and fail count belong to
GUARD_CLIENT_LAST="$GUARD_DIR/last_client"   # steamclient.so id the most recent boot ran
GUARD_CLIENT_GOOD="$GUARD_DIR/good_client"   # steamclient.so id of the last boot that started cleanly
GUARD_LOG="$GUARD_DIR/guard.log"

# Tunables (overridable for testing).
[ -n "${SLSM_GUARD_MAX_FAILS:-}" ] || SLSM_GUARD_MAX_FAILS=3
[ -n "${SLSM_GUARD_STARTUP_SECS:-}" ] || SLSM_GUARD_STARTUP_SECS=180
[ -n "${SLSM_GUARD_DUMPS_DIR:-}" ] || SLSM_GUARD_DUMPS_DIR="/tmp/dumps"

guard_log() {
	printf '%s %s\n' "$(date '+%F %T' 2>/dev/null)" "$1" >> "$GUARD_LOG" 2>/dev/null || true
}
# Non-blocking, auto-dismissing notice (10s, normal urgency). NOT critical:
# the freedesktop spec lets the shell pin critical notifications on screen with
# no timeout (KDE does), which is why an earlier critical recovery notice never
# went away. Best-effort; never blocks the launch.
guard_notify() {
	if command -v notify-send >/dev/null 2>&1; then
		notify-send -u normal -t 10000 "Steam recovery mode" "$1" >/dev/null 2>&1 || true
	fi
}
guard_read_int() {
	_v="$(cat "$1" 2>/dev/null)"
	case "$_v" in ''|*[!0-9]*) printf 0 ;; *) printf '%s' "$_v" ;; esac
}
# Identify the machine's current session. The kernel's boot_id changes on every
# boot; btime (boot epoch) is the fallback. Empty when neither is readable, in
# which case the state simply never looks stale and the guard keeps its old
# persistent behaviour instead of re-arming on every launch.
guard_session_id() {
	_sid="$(cat /proc/sys/kernel/random/boot_id 2>/dev/null || true)"
	[ -n "$_sid" ] || _sid="$(sed -n 's/^btime //p' /proc/stat 2>/dev/null || true)"
	printf '%s' "$_sid"
}
# A launch with no display tells us nothing about the injected stack: Steam
# cannot open a display, dies inside libX11 (XQueryExtension) and writes an
# ordinary crash_*.dmp on its way out - vanilla Steam included. Scripted or
# remote launches must not be able to latch recovery mode for a graphical
# session that was never started.
guard_has_display() {
	[ -n "${DISPLAY:-}" ] || [ -n "${WAYLAND_DISPLAY:-}" ]
}
# Identify the Steam client library (size:mtime of the 64-bit steamclient.so we
# hook). A client self-update rewrites it, changing this id - the signal that a
# startup crash is a compatibility break rather than a one-off. Empty when no
# client is found yet (fresh install): callers then stay conservative.
guard_client_fp() {
	for _r in "$HOME/.steam/steam" "$HOME/.steam/debian-installation" "$HOME/.local/share/Steam"; do
		_c="$_r/steamrt64/steamclient.so"
		if [ -e "$_c" ]; then
			stat -c '%s:%Y' "$_c" 2>/dev/null || stat -f '%z:%m' "$_c" 2>/dev/null || printf '?'
			return 0
		fi
	done
	printf ''
}
# Fingerprint the injected payload (size:mtime of each piece). Updating ANY of
# it - which the plugin does on reinstall/update - changes this, so a stuck
# safe-mode latch auto-clears once the user has updated.
guard_fingerprint() {
	for _f in "$SLSDIR/SLSsteam.so" \
	          "$HOME/.local/share/CloudRedirect/cloud_redirect.so" \
	          "$HOME/.local/share/Lumen/lumen"; do
		if [ -e "$_f" ]; then
			stat -c '%s:%Y' "$_f" 2>/dev/null || stat -f '%z:%m' "$_f" 2>/dev/null || printf '?'
		else
			printf -- '-'
		fi
		printf '|'
	done
}
GUARD_CUR_FP="$(guard_fingerprint)"
[ -n "${SLSM_GUARD_SESSION_ID:-}" ] || SLSM_GUARD_SESSION_ID="$(guard_session_id)"

# True when Steam wrote a FATAL crash minidump during the boot that started at
# epoch $2 (marker file $1), within that boot's first STARTUP_SECS. This is the
# definitive "Steam crashed before it became usable" signal. A clean kill (Game
# Mode <-> Desktop switch, shutdown) or a quick manual quit does NOT write a
# dump, so those never count as failures - which is why we use this instead of a
# bare "the session was short" heuristic.
#
# Match ONLY crash_*.dmp (fatal: segfault/abort that takes the client down).
# Steam also writes assert_*.dmp for NON-FATAL assertions (e.g. CloudRedirect's
# cloud-save path-resolution asserts in remotestoragefilesynccontext.cpp) while
# it keeps running perfectly fine, and those land in the same /tmp/dumps within
# the startup window. A bare '*.dmp' glob counted those as startup crashes and,
# coinciding with a Steam client self-update (client-changed -> latch on first
# crash), wrongly paused the hook on a healthy desktop boot.
guard_startup_crash() {
	[ -d "$SLSM_GUARD_DUMPS_DIR" ] || return 1
	case "$2" in ''|*[!0-9]*) return 1 ;; esac
	[ "$2" -gt 0 ] || return 1
	_ref="$GUARD_DIR/.crash_win_ref"
	touch -d "@$(( $2 + SLSM_GUARD_STARTUP_SECS ))" "$_ref" 2>/dev/null || { rm -f "$_ref" 2>/dev/null; return 1; }
	_hit="$(find "$SLSM_GUARD_DUMPS_DIR" -maxdepth 1 -name 'crash_*.dmp' -newer "$1" ! -newer "$_ref" 2>/dev/null | head -n1)"
	rm -f "$_ref" 2>/dev/null
	[ -n "$_hit" ]
}

# New session? Drop the recovery state and give injection a fresh try. The fail
# count goes with it: crash dumps live in /tmp, so a previous boot's outcome is
# not assessable here anyway, and counting across boots let unrelated launches
# accumulate towards a latch the user never saw happen.
GUARD_PREV_SESSION="$(cat "$GUARD_SESSION" 2>/dev/null || true)"
if [ "$SLSM_GUARD_SESSION_ID" != "$GUARD_PREV_SESSION" ]; then
	if [ -f "$GUARD_SAFE" ]; then
		guard_log "new session -> clearing the recovery latch and retrying injection"
	fi
	rm -f "$GUARD_SAFE" "$GUARD_FP" "$GUARD_COUNT" "$GUARD_LAST" "$GUARD_GFX" 2>/dev/null || true
	printf '%s' "$SLSM_GUARD_SESSION_ID" > "$GUARD_SESSION" 2>/dev/null || true
fi

# Already latched in this session? Stay vanilla until the payload changes (user
# updated) or the session ends.
if [ -f "$GUARD_SAFE" ]; then
	if [ "$(cat "$GUARD_FP" 2>/dev/null)" = "$GUARD_CUR_FP" ]; then
		guard_log "safe mode active -> launching Steam without injection"
		slsm_exec_vanilla "$@"
	fi
	guard_log "payload changed since latch -> clearing safe mode, retrying injection"
	rm -f "$GUARD_SAFE" "$GUARD_FP" "$GUARD_COUNT" "$GUARD_LAST" 2>/dev/null || true
fi

# Assess the PREVIOUS boot: it failed only if Steam crashed at startup (wrote a
# minidump in its first STARTUP_SECS). A short but clean session is NOT a
# failure. (find/touch/stat failing degrade to "ok", so the guard never latches
# by accident.)
GUARD_FAILS="$(guard_read_int "$GUARD_COUNT")"
GUARD_CLIENT_CUR="$(guard_client_fp)"
guard_client_changed=0
guard_assessable=0
if [ -f "$GUARD_LAST" ]; then
	if [ "$(cat "$GUARD_GFX" 2>/dev/null)" = 0 ]; then
		guard_log "previous launch had no display -> its outcome is not assessed"
	else
		guard_assessable=1
	fi
fi
if [ "$guard_assessable" = 1 ]; then
	_then="$(stat -c %Y "$GUARD_LAST" 2>/dev/null || stat -f %m "$GUARD_LAST" 2>/dev/null || echo 0)"
	if guard_startup_crash "$GUARD_LAST" "$_then"; then
		GUARD_FAILS=$(( GUARD_FAILS + 1 ))
		# If the client that just crashed differs from the last client we saw
		# boot cleanly, a fresh client update is almost certainly the cause -
		# recover on the FIRST crash instead of making the user sit through
		# MAX_FAILS loops. A one-off crash on an UNCHANGED client keeps the
		# conservative threshold (it is far more likely transient/unrelated).
		_prev_client="$(cat "$GUARD_CLIENT_LAST" 2>/dev/null || true)"
		_good_client="$(cat "$GUARD_CLIENT_GOOD" 2>/dev/null || true)"
		if [ -n "$_good_client" ] && [ "$_prev_client" != "$_good_client" ]; then
			guard_client_changed=1
			guard_log "steamclient.so changed since last clean boot -> first startup crash treated as a compatibility break"
		fi
		guard_log "previous boot crashed at startup -> fail ${GUARD_FAILS}/${SLSM_GUARD_MAX_FAILS}"
	else
		[ "$GUARD_FAILS" -ne 0 ] && guard_log "previous boot ok (no startup crash) -> reset fail count"
		GUARD_FAILS=0
		# Remember the client that just booted cleanly as the known-good baseline.
		_prev_client="$(cat "$GUARD_CLIENT_LAST" 2>/dev/null || true)"
		[ -n "$_prev_client" ] && printf '%s' "$_prev_client" > "$GUARD_CLIENT_GOOD" 2>/dev/null || true
	fi
fi
printf '%s' "$GUARD_FAILS" > "$GUARD_COUNT" 2>/dev/null || true

if [ "$GUARD_FAILS" -ge "$SLSM_GUARD_MAX_FAILS" ] || { [ "$guard_client_changed" = 1 ] && [ "$GUARD_FAILS" -ge 1 ]; }; then
	guard_log "fail count ${GUARD_FAILS} (client_changed=${guard_client_changed}) -> latching safe mode, launching vanilla Steam"
	printf '%s' "$GUARD_CUR_FP" > "$GUARD_FP" 2>/dev/null || true
	: > "$GUARD_SAFE" 2>/dev/null || true
	# Drop the half-injected appinfo.vdf so vanilla Steam rebuilds a clean one;
	# the abandoned splice (written at preinit before the hook abort) is what
	# stalls the engine. Steam regenerates appinfo.vdf on next launch.
	for _r in "$HOME/.steam/steam" "$HOME/.steam/debian-installation" "$HOME/.local/share/Steam"; do
		if [ -f "$_r/appcache/appinfo.vdf" ]; then
			rm -f "$_r/appcache/appinfo.vdf" 2>/dev/null && guard_log "removed $_r/appcache/appinfo.vdf"
		fi
	done
	guard_notify "slsteam-moon paused itself for this session because Steam kept failing to start. Steam is running normally - injection is retried the next time you reboot, or right away if you update the plugin from the LuaTools menu."
	guard_log "recovery mode latched for this session; Steam will launch unhooked until the next session or a payload update"
	slsm_exec_vanilla "$@"
fi

# Mark the start of THIS boot for the next invocation's health check, record
# whether it can produce a meaningful verdict (a launch with no display cannot),
# and record the client this boot is about to run so the next assessment can tell
# whether the client changed across a crash.
: > "$GUARD_LAST" 2>/dev/null || true
if guard_has_display; then
	printf 1 > "$GUARD_GFX" 2>/dev/null || true
else
	printf 0 > "$GUARD_GFX" 2>/dev/null || true
fi
printf '%s' "$GUARD_CLIENT_CUR" > "$GUARD_CLIENT_LAST" 2>/dev/null || true

# Signed pattern metadata preflight. The normal path is cache-only and performs
# no network I/O: when both exact-module catalogs are already valid, Steam
# launches immediately and a serialized remote revalidation runs in the
# background. A new client build has no exact cache, so only that path waits for
# the helper's bounded mirror deadline before continuing with the embedded
# patterns if the network is unavailable.
slsm_pattern_steam_root() {
	for _slsm_root in "$HOME/.steam/steam" \
	                  "$HOME/.steam/debian-installation" \
	                  "$HOME/.local/share/Steam"; do
		if [ -f "$_slsm_root/steamrt64/steamclient.so" ] && \
		   [ -f "$_slsm_root/steamrt64/steamui.so" ]; then
			printf '%s' "$_slsm_root"
			return 0
		fi
	done
	return 1
}
slsm_refresh_patterns() {
	_slsm_helper="$SLSDIR/pattern-refresh"
	[ -x "$_slsm_helper" ] || return 0
	_slsm_root="$(slsm_pattern_steam_root)" || return 0
	_slsm_config_root="${XDG_CONFIG_HOME:-$HOME/.config}"
	case "$_slsm_config_root" in
		/*) ;;
		*) _slsm_config_root="$HOME/.config" ;;
	esac
	if env -u LD_AUDIT -u LD_PRELOAD -u LD_LIBRARY_PATH \
	       "$_slsm_helper" --cache-only \
	       --steam-root "$_slsm_root" --config-root "$_slsm_config_root" \
	       >/dev/null 2>&1 < /dev/null; then
		(
			trap '' HUP
			env -u LD_AUDIT -u LD_PRELOAD -u LD_LIBRARY_PATH \
			    "$_slsm_helper" \
			    --steam-root "$_slsm_root" --config-root "$_slsm_config_root"
		) >/dev/null 2>&1 < /dev/null &
	else
		env -u LD_AUDIT -u LD_PRELOAD -u LD_LIBRARY_PATH \
		    "$_slsm_helper" \
		    --steam-root "$_slsm_root" --config-root "$_slsm_config_root" \
		    >/dev/null 2>&1 < /dev/null || true
	fi
}
slsm_refresh_patterns

# The 64-bit client only loads ELF64 objects (EI_CLASS, byte 4, is 2); a 32-bit
# preload would just make the loader print an error in every process.
slsm_is_elf64() {
[ "$(od -An -tu1 -j4 -N1 "$1" 2>/dev/null | tr -d ' ')" = 2 ]
}
# CloudRedirect (optional): inject its cloud-save hook via LD_PRELOAD.
# Our build (cloudredirect-moon, deployed by the luatools installer) restores
# saves via StripCasShaLeaf and waits up to 120 s for steamclient.so, so it
# attaches on slow-bootstrap distros (Arch/CachyOS) too. It is a plain
# LD_PRELOAD library: loading it as an LD_AUDIT auditor corrupts the client
# heap (realloc(): invalid pointer) during init, so it must NOT go in the
# LD_AUDIT list. SLSsteam stays on LD_AUDIT.
# CloudRedirect's constructor self-removes itself from LD_PRELOAD so child
# processes (the game, steamwebhelper) don't inherit it.
CR_SO="$HOME/.local/share/CloudRedirect/cloud_redirect.so"
if [ -f "$CR_SO" ] && slsm_is_elf64 "$CR_SO"; then
	export LD_PRELOAD="$CR_SO${LD_PRELOAD:+:$LD_PRELOAD}"
fi

# extest (Steam Input on Wayland): SteamOS and Bazzite ship libextest, an X11
# XTEST shim that lets the Steam Controller / Steam Input drive the desktop
# cursor under Wayland (X11 has native XTEST, so it's only needed on Wayland).
# Their own desktop launchers (bazzite-steam / steam-jupiter) LD_PRELOAD it on
# Wayland. We launch the Steam binary directly — on purpose, so our LD_AUDIT and
# CloudRedirect survive (those launchers do `env LD_PRELOAD=...`, which REPLACES
# the list and would drop cloud_redirect.so) — so we replicate just this one
# preload, generically: only on Wayland and only when the lib actually exists
# (a no-op on distros that don't ship it).
if [ "${XDG_SESSION_TYPE:-}" = "wayland" ]; then
	for _ext in /usr/lib64/extest/libextest.so \
	            /usr/lib/x86_64-linux-gnu/extest/libextest.so \
	            /usr/lib/extest/libextest.so; do
		if [ -f "$_ext" ] && slsm_is_elf64 "$_ext"; then
			export LD_PRELOAD="${LD_PRELOAD:+$LD_PRELOAD:}$_ext"
			break
		fi
	done
fi

# Lumen (millennium-less LuaTools bridge): ensure Steam's CEF remote-debugging
# endpoint is enabled, then launch the Lumen sidecar DETACHED and WITHOUT the
# loader env (it must use its own static libs, not Steam's 32-bit runtime).
# Lumen injects the LuaTools frontend via CDP and hosts the backend in-process.
# Single-instance guarded so a second wrapper invocation doesn't stack sidecars
# (Lumen releases before its own lock need this). The sidecar runs without
# arguments, so only that exact command line counts as running.
LUMEN_DIR="$HOME/.local/share/Lumen"
if [ -x "$LUMEN_DIR/lumen" ] && \
   ! pgrep -u "$(id -u)" -xf "$LUMEN_DIR/lumen" >/dev/null 2>&1; then
	touch "$HOME/.steam/steam/.cef-enable-remote-debugging" 2>/dev/null || true
	touch "$HOME/.steam/debian-installation/.cef-enable-remote-debugging" 2>/dev/null || true
	env -u LD_AUDIT -u LD_PRELOAD -u LD_LIBRARY_PATH \
	    LUMEN_BACKEND_DIR="$LUMEN_DIR/luatools/backend" \
	    LUMEN_LUA_DIR="$LUMEN_DIR/lua" \
	    setsid "$LUMEN_DIR/lumen" >/dev/null 2>&1 < /dev/null &
fi

AUDIT="$SLSDIR/SLSsteam.so"

# Re-assert desktop-entry coverage without putting reconciliation on the launch
# critical path. Prefer the serialized guardian; retain the legacy CLI fallback
# during upgrades or on desktops without a working user manager.
if command -v systemctl >/dev/null 2>&1 && \
   systemctl --user --quiet is-enabled slsteam-desktop-guardian.path >/dev/null 2>&1; then
	systemctl --user start slsteam-desktop-guardian.service >/dev/null 2>&1 &
elif [ -x "$SLSDIR/ensure-desktop-coverage.sh" ]; then
	# Lowest priority we can give it: this fallback runs concurrently with Steam's
	# own start, and a pass that does have work to do is seconds of shell CPU.
	if command -v nice >/dev/null 2>&1; then
		WRAPPER="$SLSDIR/path/steam" nice -n 10 "$SLSDIR/ensure-desktop-coverage.sh" --user >/dev/null 2>&1 &
	else
		WRAPPER="$SLSDIR/path/steam" "$SLSDIR/ensure-desktop-coverage.sh" --user >/dev/null 2>&1 &
	fi
fi

if [ -n "$SLSM_INHERITED_AUDIT" ]; then
	export LD_AUDIT="$AUDIT:$SLSM_INHERITED_AUDIT"
else
	export LD_AUDIT="$AUDIT"
fi
exec "$STEAM_BIN" "$@"
EOF

	# The root-owned launcher shim refuses group/other-writable wrappers. Set the
	# complete mode explicitly so a user umask such as 0002 cannot produce 0775.
	chmod 0755 "$SLSDIR/path/steam"

	log_success "Steam wrapper created at $SLSDIR/path/steam"
	echo ""
	return 0
}

# The autostart override lives in desktop-coverage.lib.sh as
# dc_seed_autostart_override, run by the guardian's user pass.

# ---------------------------------------------------------------------------
# System launcher interception
# ---------------------------------------------------------------------------
# Every launch path (.desktop entries, terminal invocations, XDG autostart,
# third-party programs calling the steam binary) converges on the system
# launcher script.  On Arch/Fedora this is /usr/bin/steam; on Debian/Ubuntu/
# Mint it is /usr/games/steam.  These scripts are package-manager-owned and
# have NO integrity check (unlike steam.sh which is SHA-verified), so wrapping
# them is safe and survives Steam self-updates.
#
# System launcher interception and restoration live in the shared sourceable
# library loaded near the top of this script. Keeping one implementation here
# avoids divergent backup, verification, and pre-bootstrap stub behavior.

# Current launcher integration uses the shared sourceable library.
setup_system_launcher() {
	if is_immutable_distro; then
		log_info "Immutable distro: skipping system launcher interception"
		return 1
	fi
	# Do not touch Debian's pre-bootstrap Install Steam package stub. The
	# eligibility check runs before sudo, backups, or any launcher write.
	if ! ls_steam_bootstrapped; then
		log_info "Steam is not bootstrapped yet: leaving the distro installer launcher untouched"
		return 1
	fi

	LS_SLSDIR="$SLSDIR"
	LS_BACKUP_ROOT="$SLSDIR/system-launcher-backup"
	local launcher launcher_detected=0 launcher_needs_sudo=0 expected_backup
	while IFS= read -r launcher; do
		[ -n "$launcher" ] || continue
		launcher_detected=1
		expected_backup="$(ls_backup_path "$launcher")"
		if ls_is_our_shim "$launcher" && \
		   ls_shim_references_backup "$launcher" "$(ls_mirror_path "$LS_SYSTEM_BACKUP_ROOT" "$launcher")"; then
			expected_backup="$(ls_mirror_path "$LS_SYSTEM_BACKUP_ROOT" "$launcher")"
		fi
		if ! [ -w "$launcher" ] && ! ls_shim_matches_backup "$launcher" "$expected_backup"; then
			launcher_needs_sudo=1
		fi
	done < <(ls_detect_launchers)
	if [ "$launcher_detected" = 0 ]; then
		log_warn "No eligible distro Steam launcher was found"
		return 1
	fi
	if [ "$launcher_needs_sudo" = 0 ]; then
		LS_SUDO=""
	elif [ -n "${SUDO_ASKPASS:-}" ] && [ -x "${SUDO_ASKPASS:-}" ]; then
		LS_SUDO="sudo -A"
	elif [ "${SLSM_SUDO_PRIMED:-0}" = 1 ] && command -v sudo >/dev/null 2>&1; then
		LS_SUDO="sudo"
	elif [ "${SLSM_SUDO_DENIED:-0}" != 1 ] && command -v sudo >/dev/null 2>&1; then
		if sudo -v 2>/dev/null; then
			LS_SUDO="sudo"
		else
			SLSM_SUDO_DENIED=1
			LS_SUDO=""
		fi
	else
		LS_SUDO=""
	fi
	if ls_install_shims; then
		log_success "Distro Steam launcher interception is active"
		return 0
	fi
	log_warn "Could not install the distro launcher shim; user desktop coverage remains the fallback"
	return 1
}

restore_system_launchers() {
	SLSM_KEEP_LAUNCHER_BACKUP=0
	SLSM_KEEP_LAUNCHER_TREE=0
	if is_immutable_distro; then
		local launcher
		while IFS= read -r launcher; do
			[ -n "$launcher" ] || continue
			SLSM_KEEP_LAUNCHER_BACKUP=1
			SLSM_KEEP_LAUNCHER_TREE=1
			log_warn "Immutable distro has a surviving system launcher shim at $launcher; retaining the complete helper tree"
			return 1
		done < <(ls_wrapped_paths)
		return 0
	fi
	LS_SLSDIR="$SLSDIR"
	LS_BACKUP_ROOT="$SLSDIR/system-launcher-backup"
	if [ -n "${SUDO_ASKPASS:-}" ] && [ -x "${SUDO_ASKPASS:-}" ]; then
		LS_SUDO="sudo -A"
	elif command -v sudo >/dev/null 2>&1; then
		LS_SUDO="sudo"
	else
		LS_SUDO=""
	fi
	if ls_restore_shims; then
		return 0
	fi
	# A failed restore may be recoverable with the retained original. If a live
	# shim names no usable captured original, the wrapper tree itself must
	# survive uninstall so the shim remains operational.
	local launcher
	while IFS= read -r launcher; do
		[ -n "$launcher" ] || continue
		ls_referenced_backup "$launcher" >/dev/null || SLSM_KEEP_LAUNCHER_TREE=1
	done < <(ls_wrapped_paths)
	SLSM_KEEP_LAUNCHER_BACKUP=1
	log_warn "Some system launcher shims could not be restored; retaining their backups for a later retry"
	return 1
}

setup_path_and_desktop()
{
	log_info "Setting up PATH and desktop integration"
	local system_desktop_changed=0 user_desktop_changed=0

	# --- Shell PATH integration -------------------------------------------
	local rc found=0
	for rc in "$HOME/.bashrc" "$HOME/.zshrc" "$HOME/.profile"; do
		[ -f "$rc" ] || continue
		if grep -q "SLSsteam/path" "$rc" 2>/dev/null; then
			log_success "Already in $(basename "$rc")"
		else
			{
				echo ''
				echo '# SLSsteam: Add wrapper to PATH'
				echo 'export PATH="$HOME/.local/share/SLSsteam/path:$PATH"'
			} >> "$rc"
			log_success "Added wrapper to $(basename "$rc")"
		fi
		found=1
	done
	if [ "$found" = 0 ]; then
		# Create a .bashrc if no shell rc files exist (rare but possible).
		echo 'export PATH="$HOME/.local/share/SLSsteam/path:$PATH"' > "$HOME/.bashrc"
		log_success "Created ~/.bashrc with wrapper PATH"
	fi

	# --- Detect Steam binary ----------------------------------------------
	local steam_bin steam_bootstrapped=0
	steam_bin="$(detect_steam_binary)"
	if [ -z "$steam_bin" ]; then
		log_warn "Steam doesn't appear to be installed yet"
		log_warn "Install Steam first, then re-run: ./setup.sh install"
		return 0
	fi
	if ls_steam_bootstrapped; then
		steam_bootstrapped=1
		log_success "Steam data root is bootstrapped"
	else
		log_info "Steam installer stub detected before bootstrap; injection coverage is deferred"
	fi
	log_success "Found Steam binary at $steam_bin"

	# --- Mandatory user coverage, then optional system fallback -------------
	mkdir -p "$USER_APPS"
	export DC_STEAM_INSTALLED="$steam_bootstrapped"
	mkdir -p "$DC_BACKUP_ROOT" 2>/dev/null || {
		log_error "Could not create desktop backup directory: $DC_BACKUP_ROOT"
		return 1
	}

	# Same-ID user shadows are the authoritative layer and are reconciled before
	# any privilege prompt. A per-entry reconciliation failure is retryable (the
	# guardian timer/path retries it), so it must NOT abort installation of the
	# guardian itself — that would leave the machine with no ongoing self-healing,
	# which is exactly the "injection lost after reboot" failure.
	# DC_FORCE: installing is never a boot path, and the shipped coverage logic may
	# behave differently from the one that recorded the last digest, so the
	# unchanged-input fast path must not apply here.
	if DC_FORCE=1 dc_guardian_run; then
		log_success "Reconciled user desktop entries"
	else
		log_warn "Some user desktop entries could not be fully reconciled yet; the guardian will retry them"
	fi

	# User-manager integration is an acceleration/repair layer. Desktop shadows
	# remain functional if systemd --user is unavailable.
	local guardian_status
	dgu_install_units; guardian_status=$?
	[ "$guardian_status" = 1 ] && dgu_enable_units
	[ "$guardian_status" = 2 ] && log_warn "Could not install all desktop guardian units; user desktop coverage remains active"
	dgu_install_autostart_dropins; guardian_status=$?
	[ "$guardian_status" = 2 ] && log_warn "Could not install all generated-autostart drop-ins; XDG shadows remain active"

	# Enabling the units is best-effort (systemctl --user may be unreachable when
	# the installer is run via sudo/root or a non-graphical session). Verify it
	# actually took: silently-inert units are the top cause of injection being
	# lost on the next boot, so surface it clearly instead of reporting success.
	if command -v systemctl >/dev/null 2>&1; then
		if ! systemctl --user is-enabled slsteam-desktop-guardian.path >/dev/null 2>&1; then
			log_warn "Desktop guardian installed but NOT active (systemd --user unreachable at install time). Cold-boot injection self-healing is OFF; re-run this installer from your normal desktop session (not via sudo/root)."
		fi
	fi

	# Mutable systems prefer the distro launcher shim, but user-local desktop
	# coverage above remains mandatory as a safety net on every system.
	local coverage_policy=desktop
	local coverage_status_file="$SLSDIR/coverage-policy.effective"
	if setup_system_launcher; then
		coverage_policy=launcher
	elif dc_launcher_coverage_active; then
		coverage_policy=launcher
		if ls_any_shim_uses_home_backup; then
			log_warn "An older system launcher shim remains in use until the installer runs with administrator access"
		fi
	fi
	if ! dc_write_policy "$coverage_policy"; then
		log_warn "Could not persist launch coverage policy; keeping the desktop fallback"
		if ! dc_forget_policy; then
			log_warn "Could not clear the previous launch coverage policy"
		fi
		mkdir -p "$(dirname "$coverage_status_file")" 2>/dev/null || true
		printf 'desktop\n' > "$coverage_status_file" 2>/dev/null || true
		coverage_policy=desktop
	else
		rm -f -- "$coverage_status_file" 2>/dev/null || true
	fi

	if [ "$coverage_policy" = launcher ]; then
		log_info "Distro launcher shim is primary; new system desktop entries are left untouched"
	elif is_immutable_distro; then
		log_info "Immutable distro (read-only /usr): using user-level coverage only; no administrator access requested."
	elif [ "${SLSM_SUDO_DENIED:-0}" = 1 ]; then
		log_warn "Administrator access was already declined; keeping user-local coverage without retrying sudo."
	elif command -v sudo >/dev/null 2>&1; then
		# Mutable systems retain the historical system layer only when the
		# launcher shim could not be installed. Denying sudo never discards the
		# already-working user coverage.
		if ! sudo -v; then
			log_warn "Administrator access not granted: the system-wide Steam entry stays unpatched. Menu and taskbar launches still use the injected per-user entry (it wins by desktop-file-id); only a launcher pinned by absolute path to the system file would skip the wrapper. Re-run with admin access to also cover the system entry."
		else
			DC_SUDO="sudo"
			export DC_SUDO
			if SLSM_COVERAGE_POLICY=desktop DC_FORCE=1 dc_run --system; then
				system_desktop_changed=1
				log_success "Patched optional system Steam desktop entries"
			else
				log_warn "Optional system desktop fallback could not be fully applied"
			fi
		fi
	else
		log_warn "sudo not available: the system-wide Steam entry stays unpatched. Menu and taskbar launches still use the injected per-user entry (it wins by desktop-file-id); only a launcher pinned by absolute path to the system file would skip the wrapper."
	fi

	# Fallback: if the user still has no menu entry (no donor anywhere), write
	# a minimal launcher. Before Steam bootstrap it must call the distro installer
	# directly; routing that stub through our wrapper would inject into the
	# installer and could break the first Steam installation.
	if [ ! -e "$USER_DESKTOP" ]; then
		local minimal_exec="$SLSDIR/path/steam"
		local minimal_tags="$DC_SEED_TAG"
		if [ "$steam_bootstrapped" != 1 ]; then
			minimal_exec="$steam_bin"
			minimal_tags="$DC_SEED_TAG
$DC_PREBOOTSTRAP_TAG"
			log_info "Steam is not bootstrapped; keeping the minimal launcher vanilla"
		fi
		log_info "Writing a minimal Steam launcher"
		cat > "$USER_DESKTOP" << EOF
[Desktop Entry]
$SLSM_TAG
$minimal_tags
Name=Steam
Comment=Application for managing and playing games on Steam
Exec=$minimal_exec %U
Icon=steam
Terminal=false
Type=Application
Categories=Network;FileTransfer;Game;
MimeType=x-scheme-handler/steam;x-scheme-handler/steamlink;
PrefersNonDefaultGPU=true
EOF
		chmod 0644 "$USER_DESKTOP"
		user_desktop_changed=1
		log_success "Created $USER_DESKTOP"
	fi

	# Guardian reconciliation already converged user caches. Refresh here only
	# for the direct minimal fallback or a successful mutable-system pass.
	if command -v update-desktop-database >/dev/null 2>&1; then
		[ "$user_desktop_changed" = 1 ] && \
			update-desktop-database "$USER_APPS" >/dev/null 2>&1 || true
		[ "$system_desktop_changed" = 1 ] && command -v sudo >/dev/null 2>&1 && \
			sudo update-desktop-database "/usr/share/applications" >/dev/null 2>&1 || true
	fi

	echo ""
	return 0
}

install_steamstub()
{
	TARGET="$1"
	HELPERSRC="./tools/steamstub-bypass"

	if [ ! -d "$HELPERSRC" ]; then
		log_warn "Helper scripts not found at $HELPERSRC — skipping Steam Stub setup"
		return 1
	fi

	log_info "Installing Steamless helper"
	mkdir -p "$TARGET/steamstub-bypass"
	cp -v "$HELPERSRC/run-steamless.sh" "$TARGET/steamstub-bypass/"
	chmod u+x "$TARGET/steamstub-bypass/run-steamless.sh"
	# Older releases also installed scan-all.sh, which processed every app
	# whether or not its launch options opted in, and install-steamless.sh,
	# which installed whatever upstream released last, unverified.
	rm -f "$TARGET/steamstub-bypass/scan-all.sh" \
	      "$TARGET/steamstub-bypass/install-steamless.sh"

	echo ""

	# Releases bundle the Steamless kit (scripts/package.sh refuses to build
	# without it), so only a dev tree can lack it.
	if [ -f "./tools/steamless-bin/Steamless.CLI.exe" ]; then
		log_info "Installing bundled Steamless kit"
		mkdir -p "$TARGET/steamless-bin"
		cp -r ./tools/steamless-bin/. "$TARGET/steamless-bin/"
	fi

	# Without the kit a --steamless launch keeps the original executable, and
	# a game that needs it processed fails with "Application load error 6".
	if [ -f "$TARGET/steamless-bin/Steamless.CLI.exe" ]; then
		log_success "Steamless ready ($TARGET/steamless-bin)"
	else
		log_warn "Steamless kit NOT installed: games launched with --steamless keep"
		log_warn "their original executable (Application load error 6 for those"
		log_warn "that need it processed). Reinstall from a release to restore it."
	fi
	echo ""
}

install_all()
{
	print_banner

	print_section "Stopping Steam"
	kill_steam

	print_section "Installing libraries"
	install_slssteam

	print_section "Creating Steam wrapper"
	create_steam_wrapper

	print_section "Configuring PATH & desktop entry"
	setup_path_and_desktop

	print_section "Installing Steamless helper"
	install_steamstub "$SLSDIR"

	print_install_complete
}

# ============================================================================
# Uninstall
# ============================================================================

restore_or_remove_desktop() {
	local f="$1"
	local backup="$DC_BACKUP_ROOT/${f#/}" legacy
	local sudo_cmd="${2:-}"

	[ -f "$f" ] || return 0
	if [ ! -f "$backup" ]; then
		for legacy in "$f.slssteam-backup" "$f.slsteam-bak"; do
			[ -f "$legacy" ] || continue
			mkdir -p "$(dirname "$backup")" 2>/dev/null || break
			if [ -n "$sudo_cmd" ]; then
				$sudo_cmd cat -- "$legacy" > "$backup" 2>/dev/null || { rm -f "$backup"; break; }
			else
				cp -- "$legacy" "$backup" 2>/dev/null || { rm -f "$backup"; break; }
			fi
			$sudo_cmd rm -f -- "$legacy" 2>/dev/null || true
			break
		done
	fi
	if ! is_patched_desktop "$f" && [ ! -f "$backup" ]; then
		return 0
	fi

	if [ -f "$backup" ]; then
		log_info "Restoring $f from backup"
		# The user's shell opens the backup; sudo only writes the entry.
		if $sudo_cmd install -m 0644 /dev/stdin "$f" < "$backup"; then
			rm -f -- "$backup"
			log_success "Restored $f"
		fi
	else
		log_info "Removing $f (no backup found)"
		$sudo_cmd rm -- "$f"
		log_success "Removed $f"
	fi
}

uninstall()
{
	print_banner
	print_section "Uninstalling SLSsteam"
	local desktop_restore_complete=1
	local launcher_restore_complete=1

	kill_steam

	# Remove from shell rc files.
	local rc
	for rc in "$HOME/.bashrc" "$HOME/.zshrc" "$HOME/.profile"; do
		[ -f "$rc" ] || continue
		if grep -q "SLSsteam/path" "$rc" 2>/dev/null; then
			log_info "Cleaning wrapper PATH entry from $(basename "$rc")"
			sed -i '/# SLSsteam: Add wrapper to PATH/d' "$rc"
			sed -i '\|SLSsteam/path|d' "$rc"
		fi
	done

	# Stop generated launch paths before restoring their desktop-file sources.
	# Removal is sentinel-scoped and therefore preserves foreign unit drop-ins.
	if command -v dgu_remove_autostart_dropins >/dev/null 2>&1; then
		dgu_remove_autostart_dropins || true
	fi
	if command -v dgu_remove_units >/dev/null 2>&1; then
		dgu_remove_units || true
	fi

	# Restore every patched/symlinked *steam*.desktop (menu user+system incl. the
	# stub, ~/Desktop shortcut, autostart user+system) from their backups via the
	# shared lib. System paths use sudo when available.
	if command -v dc_restore_all >/dev/null 2>&1; then
		if is_immutable_distro || ! command -v sudo >/dev/null 2>&1; then
			DC_SUDO=""
		else
			DC_SUDO="sudo"
		fi
		export DC_SUDO
		if dc_restore_all; then
			log_success "Restored Steam desktop entries"
		else
			desktop_restore_complete=0
			log_warn "System desktop restoration is unavailable; retaining user desktop coverage and helpers for a later retry"
		fi
	else
		# Lib unavailable (older layout): fall back to the legacy per-file restore.
		restore_or_remove_desktop "$USER_DESKTOP"
		[ -f "$SYS_DESKTOP" ] && command -v sudo >/dev/null 2>&1 && \
			restore_or_remove_desktop "$SYS_DESKTOP" sudo
	fi
	if command -v update-desktop-database >/dev/null 2>&1; then
		update-desktop-database "$USER_APPS" >/dev/null 2>&1 || true
		! is_immutable_distro && command -v sudo >/dev/null 2>&1 && \
			sudo update-desktop-database "/usr/share/applications" >/dev/null 2>&1 || true
	fi

	# Restore any wrapped system launchers before removing the dir.
	if restore_system_launchers; then
		launcher_restore_complete=1
	else
		launcher_restore_complete=0
	fi
	# Legacy: the in-place /usr/games/steam patch of older versions. The
	# current shim at that path names SLSsteam too and is restored above.
	local legacy="${SLSM_LEGACY_LAUNCHER:-/usr/games/steam}"
	if ! is_immutable_distro && [ -f "$legacy" ] && ! ls_is_our_shim "$legacy" &&
	   grep -q "SLSsteam" "$legacy" 2>/dev/null; then
		log_info "Found legacy $legacy modification"
		if [ -f "$legacy.slsteam-backup" ]; then
			log_info "Restoring original $legacy (requires sudo)"
			sudo cp "$legacy.slsteam-backup" "$legacy"
			sudo rm "$legacy.slsteam-backup"
			log_success "Restored $legacy"
		else
			log_warn "Legacy modification found but no backup exists"
		fi
	fi

	# Policy state lives outside SLSDIR. Forget it only after launcher restore;
	# retaining it with a surviving shim keeps interrupted uninstalls recoverable.
	if [ "$launcher_restore_complete" = 1 ]; then
		if command -v dc_forget_policy >/dev/null 2>&1; then
			dc_forget_policy || true
		else
			local state_home="${XDG_STATE_HOME:-$HOME/.local/state}"
			case "$state_home" in
				/*) : ;;
				*) state_home="$HOME/.local/state" ;;
			esac
			rm -f -- "$state_home/slsteam-moon/coverage.policy" 2>/dev/null || true
		fi
	else
		log_warn "Keeping coverage.policy while a system launcher shim still needs restoration"
	fi

	if [ "${SLSM_KEEP_LAUNCHER_TREE:-0}" = 1 ] && [ -d "$SLSDIR" ]; then
		log_warn "Keeping $SLSDIR because a system launcher has no recoverable original"
	elif [ "${SLSM_KEEP_LAUNCHER_BACKUP:-0}" = 1 ] && [ -d "$SLSDIR" ]; then
		log_warn "Keeping $SLSDIR/system-launcher-backup because a system launcher shim could not be restored"
		find "$SLSDIR" -mindepth 1 -maxdepth 1 \
			! -name system-launcher-backup -exec rm -rf -- {} + 2>/dev/null || true
	elif [ -d "$SLSDIR" ] && [ "$desktop_restore_complete" = 1 ]; then
		log_info "Removing $SLSDIR"
		rm -rf "$SLSDIR"
	elif [ -d "$SLSDIR" ]; then
		log_warn "Keeping $SLSDIR because desktop restoration is incomplete"
	fi

	print_uninstall_complete
}

# ============================================================================
# Entry point
# ============================================================================

if [ "${SLS_SETUP_LIB_ONLY:-0}" = 1 ]; then
	if [[ "${BASH_SOURCE[0]}" != "$0" ]]; then
		return 0
	fi
	exit 0
fi

if [[ $# -lt 1 ]]; then
	print_banner
	echo -e "${BOLD}Usage:${NC}  $0 ${GREEN}install${NC} | ${GREEN}uninstall${NC}"
	echo ""
	exit 0
fi

if [ "$1" == "install" ]; then
	install_all
elif [ "$1" == "uninstall" ]; then
	uninstall
else
	log_error "Unknown command: $1"
	echo -e "${BOLD}Usage:${NC}  $0 ${GREEN}install${NC} | ${GREEN}uninstall${NC}"
	exit 1
fi
